#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/timer/tmr0.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/system/pins.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>    

// =================== DEFINICIONES MANUALES DE LEDS ===================
#define LED_G00_LAT LATDbits.LATD0
#define LED_M03_LAT LATDbits.LATD1
#define LED_M05_LAT LATDbits.LATD2
#define LED_G28_LAT LATDbits.LATD3

#define LED_G00_SetHigh()  (LED_G00_LAT = 1)
#define LED_G00_SetLow()   (LED_G00_LAT = 0)
#define LED_M03_SetHigh()  (LED_M03_LAT = 1)
#define LED_M03_SetLow()   (LED_M03_LAT = 0)
#define LED_M05_SetHigh()  (LED_M05_LAT = 1)
#define LED_M05_SetLow()   (LED_M05_LAT = 0)
#define LED_G28_SetHigh()  (LED_G28_LAT = 1)
#define LED_G28_SetLow()   (LED_G28_LAT = 0)

volatile int16_t number1 = 14500; 
volatile int16_t number2 = 10000;
volatile int16_t number3 = 4500; 
volatile int16_t number4 = 50; 

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G28,
    CMD_S,
    CMD_A,
    CMD_P,
    CMD_Ki,
    CMD_Kp,
    CMD_Kd        
} CommandID;

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    int16_t value;
    bool valid;
} SetPoint_Command;

typedef struct {
    float Ki, Kp, Kd;
} K_PID;

K_PID Constantes;

typedef struct {
    SystemState state;
    UART_Message msg;
    SetPoint_Command pos;
    CommandID cmdID;
    bool txReady;
} SystemContext;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .cmdID = CMD_NONE,
    .txReady = false
};

// =================== PROTOTIPOS ===================
static SetPoint_Command parseP(const char *input);
static float parseK_PID(const char *input);
static int decodeGcode(const char *input);
void RxFSM(void);


void main(void)
{
    // Inicializaci�n del sistema
    SYSTEM_Initialize();
    
    // Registrar callback de UART1
    UART1_SetRxInterruptHandler(UART1_CustomHandler);

    // Registrar callback de TMR0 (ejemplo: enviar algo cada interrupci�n)
    TMR0_PeriodMatchCallbackRegister(TMR0_UserInterrupt);

    // Habilitar interrupciones globales
    INTCON0bits.GIEH = 1;  // Habilita interrupciones globales
    INTCON0bits.GIEL = 1;  // Habilita interrupciones perif�ricas

    // Apagar todos los LEDs antes de procesar el nuevo comando
    LED_G00_SetLow();
    LED_M03_SetLow();
    LED_M05_SetLow();
    LED_G28_SetLow();
    
    Constantes.Ki = 1.1;
    Constantes.Kp = 1.2;
    Constantes.Kd = 1.3;
    
    // Loop principal
    while (1)
    {
        RxFSM();
    }
}


// =================== DECODIFICADOR DE COMANDOS ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "S", 1) == 0) return CMD_S;
    if (strncmp(input, "A", 1) == 0) return CMD_A;
    if (strncmp(input, "P", 1) == 0) return CMD_P;
    if (strncmp(input, "Ki", 1) == 0) return CMD_Ki;
    if (strncmp(input, "Kp", 1) == 0) return CMD_Kp;
    if (strncmp(input, "Kd", 1) == 0) return CMD_Kd;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}


static SetPoint_Command parseP(const char *input) {
    SetPoint_Command cmd = {0, false};

    // Apunta al n�mero despu�s de la 'P'
    const char *numPtr = input + 1;

    // Verifica formato: debe haber signo opcional seguido de d�gitos
    if (*numPtr == '+' || *numPtr == '-' || isdigit((unsigned char)*numPtr)) {
        int val = atoi(numPtr);
        if (val >= -14500 && val <= 14500) {
            cmd.value = (int16_t)val;
            cmd.valid = true;
        }
    }

    return cmd;
}

static float parseK_PID(const char *input){
    float val = 0.0f;
    float frac = 0.0f;
    float divisor = 10.0f;
    bool decimal = false;

    // Leemos manualmente caracteres del 4 al 8 (�ndices 3..7)
    char c;

    c = input[3];
    if (c == ',') decimal = true;
    else if (c >= '0' && c <= '9') {
        if (!decimal) val = val * 10 + (c - '0');
        else { val += (c - '0') / divisor; divisor *= 10; }
    }

    c = input[4];
    if (c == ',') decimal = true;
    else if (c >= '0' && c <= '9') {
        if (!decimal) val = val * 10 + (c - '0');
        else { val += (c - '0') / divisor; divisor *= 10; }
    }

    c = input[5];
    if (c == ',') decimal = true;
    else if (c >= '0' && c <= '9') {
        if (!decimal) val = val * 10 + (c - '0');
        else { val += (c - '0') / divisor; divisor *= 10; }
    }

    c = input[6];
    if (c == ',') decimal = true;
    else if (c >= '0' && c <= '9') {
        if (!decimal) val = val * 10 + (c - '0');
        else { val += (c - '0') / divisor; divisor *= 10; }
    }

    c = input[7];
    if (c == ',') decimal = true;
    else if (c >= '0' && c <= '9') {
        if (!decimal) val = val * 10 + (c - '0');
        else { val += (c - '0') / divisor; divisor *= 10; }
    }

    return val;
}

// =================== MAQUINA DE ESTADOS DE RECEPCI�N ===================
void RxFSM(void)
{
    if (uartRxTail == uartRxHead) return; // No hay mensajes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    systemCtx.cmdID = (CommandID)decodeGcode(msg);
        
    switch (systemCtx.cmdID) {
        case CMD_P:
            systemCtx.pos = parseP(msg);
            if (systemCtx.pos.valid) {
                number1 = systemCtx.pos.value;
                LED_G00_SetHigh();
            } else {
                LED_G00_SetLow();
            }
            break;

        case CMD_G28:
            LED_G28_SetHigh();
            //GoHome();
            break;

        case CMD_S:
            LED_M03_SetHigh();  // ? Activa SERIAL
            break;

        case CMD_A:
            LED_M05_SetHigh();  // ? Activa VOLTAJE
            break;
            
        case CMD_Ki:
            Constantes.Ki = parseK_PID(msg);
            number2 = (int16_t)(Constantes.Ki * 10);
            break;
            
        case CMD_Kp:
            Constantes.Kp = parseK_PID(msg);
            number3 = (int16_t)(Constantes.Kp * 10);
            break;
            
        case CMD_Kd:
            Constantes.Kd = parseK_PID(msg);
            number4 = (int16_t)(Constantes.Kd * 10);
            break;  
            
        default:
            LED_M03_SetLow();
            LED_M05_SetLow();
            LED_G28_SetLow();
            break;
    }

    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}
