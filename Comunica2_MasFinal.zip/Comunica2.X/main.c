/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F46K42
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/fvr/fvr.h"
#include "mcc_generated_files/pwm/pwm5.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/timer/tmr2.h"
#include "mcc_generated_files/timer/tmr6.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stddef.h>   /* Para NULL */

volatile bool Analog_ref;
volatile bool adc_ready;
volatile int16_t pulse;

//Encoder
volatile int16_t valor_Enc;

#define MAX_TASKS 10

volatile int32_t PulsosEncoder = 0; 
int16_t SetPoint = 0; 
int16_t PosActual = 0;
int16_t Error = 0; 
int16_t SalidaPID = 0; 
volatile bool Ts = false;

const float Nf = 50;
const float ts = 0.008;
float alpha = ( Nf * ts ) / ( 1 + Nf * ts );

int16_t AN2_b;
int16_t AN3_b;

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G28,
    CMD_S,
    CMD_A,
    CMD_P,
    CMD_Ki,
    CMD_Kp,
    CMD_Kd        
} CommandID;

typedef enum {
    PID_ETAPA_0_LECTURA,
    PID_ETAPA_1_ERROR,
    PID_ETAPA_2_P,
    PID_ETAPA_3_I,
    PID_ETAPA_4_D,
    PID_ETAPA_5_SALIDA
} PID_Etapa_t;

typedef enum {
    NONE,
    Rx1,
    Rx2,
    Rx3,
    Rx4
} Envio_Datos;

typedef void (*TaskFunction)(int16_t, bool);

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    int16_t value;
    bool valid;
} SetPoint_Command;

typedef struct {
    float Ki;
    float Kp;
    float Kd;
} K_PID;

K_PID Constantes;

Envio_Datos transmision = NONE;

typedef enum {
    PID_FSM_IDLE = 0,
    PID_FSM_READING
} PID_FSM_State;

typedef enum {
    PID_TARGET_NONE = 0,
    PID_TARGET_KP,
    PID_TARGET_KI,
    PID_TARGET_KD
} PID_Target;

typedef struct {
    PID_Etapa_t etapa;
    int16_t SetPointActual;
    int16_t PosActual;
    int16_t Error;
    int16_t ErrorPrev;
    int32_t SumError;
    int16_t Derivada;
    float P;
    float I;
    float D;
    float Acumulado;
    bool habilitado;
    bool digital;
} PID_Data_t;

/* Inicializaci�n C90 v�lida */
volatile PID_Data_t PID = {
    PID_ETAPA_0_LECTURA,  /* etapa */
    0,
    0,                    /* PosActual */
    0,                    /* Error */
    0,                    /* ErrorPrev */
    0,                    /* SumError */
    0,                    /* Derivada */
    0.0f,                 /* P */
    0.0f,                 /* I */
    0.0f,                 /* D */
    0.0f,                 /* Acumulado */
    false,                 /* habilitado */
    true
};

typedef struct {
    PID_FSM_State state;
    PID_Target target;
    float value;
    float divisor;
    bool decimalMode;
    uint8_t index;
    const char *buffer;
} K_PID_FSM;

K_PID_FSM KParser; /* Se inicializa en runtime */

typedef struct {
    SystemState state;
    UART_Message msg;
    SetPoint_Command pos;
    CommandID cmdID;
    bool txReady;
    bool digital;
} SystemContext;

/* Inicializaci�n v�lida */
SystemContext systemCtx = {
    STATE_IDLE,           /* state */
    {"", 0, false},       /* msg */
    {0, false},           /* pos */
    CMD_NONE,             /* cmdID */
    false,                /* txReady */
    true                  /* digital */
};

typedef struct {
    TaskFunction func;
    int16_t pos;
    bool started;
    bool digital;
    uint8_t iterations;
} Task;

typedef struct {
    Task queue[MAX_TASKS];
    uint8_t head;
    uint8_t tail;
    bool running;
} TaskScheduler;

/* Inicializaci�n v�lida */
TaskScheduler scheduler = {
    { {0} }, /* queue */
    0,       /* head */
    0,       /* tail */
    false    /* running */
};


// =================== PROTOTIPOS ===================
static SetPoint_Command parseP(const char *input);
void K_PID_FSM_Process(void);
static int decodeGcode(const char *input);
void RxFSM(void);
void PID_MDF(void);
void PID_Reset(void);
void Rx_datos(void);
void GoHome(int16_t, bool);
void GoTo(int16_t, bool);
void StartTask(TaskFunction, int16_t, bool);
void RunTasks(void);

void main(void)
{
    // Inicializaci�n del sistema
    SYSTEM_Initialize();
    
    // Registrar callback de UART1
    UART1_SetRxInterruptHandler(UART1_CustomHandler);
    
    // Habilitar interrupciones globales
    INTCON0bits.GIEH = 1;  // Habilita interrupciones globales
    INTCON0bits.GIEL = 1;  // Habilita interrupciones perif�ricas
    
    float Kp = 0.00026;
    float Ki = 0.00001;
    float Kd = 0.00004;
    
    Constantes.Kp = Kp;
    Constantes.Ki = Ki * ts;
    Constantes.Kd = ( Kd*alpha ) / ts;
    
    PWM5_LoadDutyValue(0);
    
    // Loop principal
    while (1)
    {
        RxFSM();
        K_PID_FSM_Process();
        
        if (Ts) {                   // ? solo se ejecuta una vez por periodo
            Ts = false;             // ? limpia la bandera
            transmision = Rx1;      // ? ejecuta el control PID o tareas dependientes del muestreo
            RunTasks();             // ? avanza una iteraci�n de la tarea actual
        }
        
        PID_MDF();
        Rx_datos();
    }
}


// =================== DECODIFICADOR DE COMANDOS ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "S", 1) == 0) return CMD_S;
    if (strncmp(input, "A", 1) == 0) return CMD_A;
    if (strncmp(input, "P", 1) == 0) return CMD_P;
    if (strncmp(input, "Ki", 2) == 0) return CMD_Ki;
    if (strncmp(input, "Kp", 2) == 0) return CMD_Kp;
    if (strncmp(input, "Kd", 2) == 0) return CMD_Kd;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}


static SetPoint_Command parseP(const char *input) {
    SetPoint_Command cmd = {0, false};

    // Apunta al n�mero despu�s de la 'P'
    const char *numPtr = input + 1;

    // Verifica formato: debe haber signo opcional seguido de d�gitos
    if (*numPtr == '+' || *numPtr == '-' || isdigit((unsigned char)*numPtr)) {
        int val = atoi(numPtr);
        if (val >= -14500 && val <= 14500) {
            cmd.value = (int16_t)val;
            cmd.valid = true;
        }
    }
    return cmd;
}

void K_PID_FSM_Process(void) {
    if (KParser.state == PID_FSM_IDLE) return;

    char c = KParser.buffer[KParser.index];

    if (c == ',') {
        KParser.decimalMode = true;
    }
    else if (c >= '0' && c <= '9') {
        if (!KParser.decimalMode) {
            KParser.value = KParser.value * 10.0f + (c - '0');
        } else {
            KParser.value += (float)(c - '0') / KParser.divisor;
            KParser.divisor *= 10.0f;
        }
    }

    KParser.index++;

    if (KParser.index > 7) {
        // FIN ? asignar seg�n target
        switch(KParser.target) {
            case PID_TARGET_KP: 
                Constantes.Kp = KParser.value;
                break;
            case PID_TARGET_KI: 
                Constantes.Ki = KParser.value*ts;
                break;
            case PID_TARGET_KD: 
                Constantes.Kd = ( KParser.value*alpha ) / ts;
                break;
            default: 
                break;
        }

        // Volver a reposo
        KParser.state = PID_FSM_IDLE;
        KParser.target = PID_TARGET_NONE;
    }
}


// =================== MAQUINA DE ESTADOS DE RECEPCI�N ===================
void RxFSM(void)
{
    if (uartRxTail == uartRxHead) return; // No hay mensajes
    
    char *msg = (char*)uartRxBuffer[uartRxTail];
    
    systemCtx.cmdID = (CommandID)decodeGcode(msg);
        
    switch (systemCtx.cmdID) {
        case CMD_P:
            systemCtx.pos = parseP(msg);
            if (systemCtx.pos.valid && systemCtx.digital) {
                StartTask(GoTo, systemCtx.pos.value , true);
            } else {
            
            }
            break;
            
        case CMD_G28:
            StartTask(GoHome, 0, false);
            
            break;

        case CMD_S:
            systemCtx.digital = true;
            break;

        case CMD_A:
            systemCtx.digital = false;
            AN3_b = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA3);
            StartTask(GoTo, (int16_t)((AN3_b - 2047)*7.1f) , false);
            break;
            
        case CMD_Kp:
            //agregar el if de que actuliza las constantes si esta ejecutando una tarea
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KP;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Ki:
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KI;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Kd:
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KD;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

            
        default:

            break;
    }

    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}

void Rx_datos(void){
    switch(transmision)
    {
        case Rx1:
            UART1_SendNumber(SetPoint);
            transmision = Rx2;
            break;
            
        case Rx2:
            //UART1_SendNumber(PosActual);
            UART1_SendNumber(PosActual);
            transmision = Rx3;
            break;
            
        case Rx3:
            //UART1_SendNumber(Error);
            UART1_SendNumber(Error);
            transmision = Rx4;
            break;
            
        case Rx4:
            //UART1_SendNumber(SalidaPID);
            UART1_SendNumber(SalidaPID);
            transmision = NONE;
            break;
            
        case NONE:
            break;
    }
}

void PID_MDF(void)
{
    if(!PID.habilitado)
        return;

    switch(PID.etapa)
    {
        case PID_ETAPA_0_LECTURA:
            if(PID.digital){
                PID.PosActual = (int16_t)( PulsosEncoder * 3.5f );
            }
            else {
                AN2_b = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2);
                PID.PosActual = (int16_t)((AN2_b - 2048)*7.1f);
            }
            PID.etapa = PID_ETAPA_1_ERROR;
            break;

        case PID_ETAPA_1_ERROR:
            PID.Error = PID.SetPointActual - PID.PosActual;
            PID.SumError += PID.Error;
            PID.SumError += PID.Error;
            PID.Derivada = PID.Error - PID.ErrorPrev;
            PID.ErrorPrev = PID.Error;
            PID.etapa = PID_ETAPA_2_P;
            break;

        case PID_ETAPA_2_P:
            PID.P = Constantes.Kp * PID.Error;
            PID.Acumulado = PID.P;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA; 
                break;
            }
            PID.etapa = PID_ETAPA_3_I;
            break;

        case PID_ETAPA_3_I:
            PID.I = Constantes.Ki * (float)PID.SumError;
            PID.Acumulado += PID.I;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA;
                break;
            }
            PID.etapa = PID_ETAPA_4_D;
            break;

        case PID_ETAPA_4_D:
            PID.D = Constantes.Kd * (float)PID.Derivada;
            PID.Acumulado += PID.D;
            PID.etapa = PID_ETAPA_5_SALIDA;
            break;

        case PID_ETAPA_5_SALIDA:
            // Saturaci�n final
            if(PID.Acumulado >  24.0f) PID.Acumulado =  24.0f;
            if(PID.Acumulado < -24.0f) PID.Acumulado = -24.0f;

            PosActual = PID.PosActual;
            Error = PID.Error;
            SalidaPID = (int16_t)(PID.Acumulado * 42.625f);
            
            PWM5_LoadDutyValue(SalidaPID);
            
            break;
    }
}


void PID_Reset(void) {
    PID.etapa = PID_ETAPA_0_LECTURA;
    PID.Error = 0;
    PID.ErrorPrev = 0;
    PID.SumError = 0;
    PID.Derivada = 0;
    PID.P = 0;
    PID.I = 0;
    PID.D = 0;
    PID.Acumulado = 0;
}


void GoHome(int16_t dummy, bool digital) {
    (void)dummy;  // sin uso
    // por ejemplo, resetear posici�n
    PID_Reset();
    PID.habilitado = true;
}


void GoTo(int16_t pos, bool digital) {
    PID_Reset();
    PID.habilitado = true;
}


void StartTask(void (*func)(int16_t, bool), int16_t pos, bool digital) {
    uint8_t next = (scheduler.tail + 1) % MAX_TASKS;
    if (next != scheduler.head) {
        scheduler.queue[scheduler.tail].func = func;
        scheduler.queue[scheduler.tail].pos = pos;
        scheduler.queue[scheduler.tail].digital = digital;
        scheduler.queue[scheduler.tail].started = false;
        scheduler.tail = next;
    }
}


void RunTasks(void) {
    if (scheduler.head == scheduler.tail) {
        scheduler.running = false;
        return;
    }

    scheduler.running = true;
    Task *current = &scheduler.queue[scheduler.head];

    // Nueva tarea
    if (!current->started) {
        current->started = true;
        current->iterations = 0;

        // Reinicia PID solo al inicio de la tarea
        SetPoint = current->pos;
        
        PID.SetPointActual = SetPoint;
        PID.digital = current->digital;
    }

    // Ejecutar la tarea (GoTo o GoHome)
    current->func(current->pos, current->digital);

    // Contar iteraciones
    current->iterations++;

    // Condici�n de fin: error menor a 10 o l�mite m�ximo de iteraciones
    if ( current->iterations >= 55 ) {
        scheduler.head = (scheduler.head + 1) % MAX_TASKS;
        PWM5_LoadDutyValue(0);
        SalidaPID = 0;
        PID.habilitado = false;
        if( current->pos == 0 && !current->digital ){
            PulsosEncoder = 0;
        }
    }
}

