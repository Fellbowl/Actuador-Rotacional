/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F18426
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/pin_manager.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G00,
    CMD_M03,
    CMD_M05,
    CMD_G28
} CommandID;

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    uint16_t posX;
    uint16_t velY;
    bool valid;
} G00_Command;

typedef struct {
    SystemState state;
    UART_Message msg;
    G00_Command g00;
    CommandID cmdID;
    bool txReady;
} SystemContext;

volatile char lastChar = 0;
void __interrupt() ISR(void);
static G00_Command parseG00(const char *input);
static int decodeGcode(const char *input);
void UART1_CustomHandler(void);
void RxFSM(void);

#define UART_RX_BUFFER_SIZE 16   // m?ximo de mensajes pendientes
#define UART_MSG_LEN 64          // m?ximo de caracteres por mensaje
volatile char uartRxBuffer[UART_RX_BUFFER_SIZE][UART_MSG_LEN];
volatile uint8_t uartRxHead = 0; // ?ndice del mensaje actual en construcci?n
volatile uint8_t uartRxTail = 0; // ?ndice del mensaje a procesar
volatile uint8_t uartCharPos = 0; // posici?n dentro del mensaje actual
volatile bool rxDataReady = false;
volatile bool txFlag = false;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .g00 = {0, 0, false},
    .cmdID = CMD_NONE,
    .txReady = false
};


void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    UART1_SetRxInterruptHandler(UART1_CustomHandler);

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    /*StartTask(GoHome, 0, 24000);*/
    
    // 2. Mover a posici�n 1500
   // StartTask(GoTo, 1500, 10000);

    // 3. Mover a posici�n 0 (volver al inicio)
   // StartTask(GoTo, 0, 10000);
    
    while (1)
    {
        RxFSM();
    }
}


void UART1_CustomHandler(void)
{
    uint8_t dato = UART1_Read();

    uint8_t nextHead = (uartRxHead + 1) % UART_RX_BUFFER_SIZE;

    if (nextHead != uartRxTail) {
        uartRxBuffer[uartRxHead][uartCharPos++] = dato;

        if (dato == '\n' || uartCharPos >= UART_MSG_LEN - 1) {
            uartRxBuffer[uartRxHead][uartCharPos] = '\0';
            uartCharPos = 0;
            uartRxHead = nextHead;
            rxDataReady = true;
        }
    }
}


// =================== FUNCIONES AUXILIARES ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "G00", 3) == 0) return CMD_G00;
    if (strncmp(input, "M03", 3) == 0) return CMD_M03;
    if (strncmp(input, "M05", 3) == 0) return CMD_M05;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}

static G00_Command parseG00(const char *input) {
    G00_Command cmd = {0, 0, false};
    const char *xPtr = strchr(input, 'X');
    const char *yPtr = strchr(input, 'Y');

    if (xPtr && yPtr) {
        int x = atoi(xPtr + 1);
        int y = atoi(yPtr + 1);
        if (x >= 0 && x <= 2000 && y >= 0 && y <= 24000) {
            cmd.posX = (uint16_t)x;
            cmd.velY = (uint16_t)y;
            cmd.valid = true;
        }
    }
    return cmd;
}

void RxFSM(void)
{
    // Procesar solo un mensaje pendiente (no usar while)
    if (uartRxTail == uartRxHead) return; // no hay mensajes pendientes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    // Decodificar comando
    systemCtx.cmdID = decodeGcode(msg);

    switch (systemCtx.cmdID) {
        case CMD_G00:
            systemCtx.g00 = parseG00(msg);
            if (systemCtx.g00.valid) {

            }
            break;

        case CMD_G28:
 
            break;

        default:

            break;
    }

    // Avanzar cola (un mensaje procesado)
    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}