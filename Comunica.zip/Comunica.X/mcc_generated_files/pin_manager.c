#include <xc.h>
#include <string.h>
#include "uart1.h"

/* Buffer sizes */
#define UART1_TX_BUFFER_SIZE 8
#define UART1_RX_BUFFER_SIZE 8

/* Buffers */
static volatile uint8_t uartRxBuffer[UART1_RX_BUFFER_SIZE];
static volatile uint8_t uartTxBuffer[UART1_TX_BUFFER_SIZE];
static volatile uint8_t uartRxHead = 0;
static volatile uint8_t uartRxTail = 0;
static volatile uint8_t uartTxHead = 0;
static volatile uint8_t uartTxTail = 0;

/* =============================
 *  Inicializaci�n UART1
 * ============================= */
void UART1_Initialize(void)
{
    // Configurar pines TX y RX (ajusta seg�n tus pines reales)
    TRISCbits.TRISC6 = 1;  // RX1 (RC6)
    TRISCbits.TRISC7 = 0;  // TX1 (RC7)

    // Desactivar m�dulo antes de configurar
    U1CON0bits.ON = 0;

    // Configuraci�n b�sica
    U1CON0bits.BRGS = 1;   // Alta velocidad (4x)
    U1CON0bits.MODE = 0b000; // Modo as�ncrono 8 bits
    U1CON0bits.TXEN = 1;   // Habilitar transmisi�n
    U1CON0bits.RXEN = 1;   // Habilitar recepci�n

    // Configuraci�n de control
    U1CON1bits.ON = 1;     // Encender UART1
    U1CON1bits.SIDL = 0;   // Continuar en modo idle

    // Baud rate = Fosc / (4 * (U1BRG + 1))
    // Si Fosc = 16 MHz y queremos 9600 bps:
    // U1BRG = (16000000 / (4*9600)) - 1 = 416.66 ? 416
    U1BRGL = 0xA0;  // 9600 @ 16MHz (ajusta seg�n tu frecuencia)
    U1BRGH = 0x01;

    // Limpiar banderas e interrupciones
    PIR4bits.U1RXIF = 0;
    PIR4bits.U1TXIF = 0;
    PIE4bits.U1RXIE = 1;  // Habilitar interrupci�n RX
    PIE4bits.U1TXIE = 0;  // TX se activa cuando haya datos

    // Activar m�dulo UART1
    U1CON1bits.ON = 1;
}

/* =============================
 *  Interrupci�n de recepci�n
 * ============================= */
void __interrupt(irq(U1RX), high_priority) UART1_Receive_ISR(void)
{
    uint8_t dato = U1RXB;  // Leer dato recibido limpia la bandera

    // Detectar error de overflow o framing
    if (U1ERRIRbits.RXFOIF) {
        U1ERRIRbits.RXFOIF = 0; // Limpiar overflow
    }

    uint8_t nextHead = (uartRxHead + 1) % UART1_RX_BUFFER_SIZE;
    if (nextHead != uartRxTail) {
        uartRxBuffer[uartRxHead] = dato;
        uartRxHead = nextHead;
    }
}

/* =============================
 *  Transmisi�n
 * ============================= */
void UART1_Write(uint8_t data)
{
    uint8_t nextHead = (uartTxHead + 1) % UART1_TX_BUFFER_SIZE;

    // Esperar espacio libre
    while (nextHead == uartTxTail);

    uartTxBuffer[uartTxHead] = data;
    uartTxHead = nextHead;

    PIE4bits.U1TXIE = 1; // Habilitar interrupci�n TX
}

void __interrupt(irq(U1TX), high_priority) UART1_Transmit_ISR(void)
{
    if (uartTxHead != uartTxTail) {
        U1TXB = uartTxBuffer[uartTxTail];
        uartTxTail = (uartTxTail + 1) % UART1_TX_BUFFER_SIZE;
    } else {
        PIE4bits.U1TXIE = 0; // No hay m�s datos
    }
}

/* =============================
 *  Lectura de datos
 * ============================= */
uint8_t UART1_Read(void)
{
    while (uartRxHead == uartRxTail); // Esperar datos
    uint8_t dato = uartRxBuffer[uartRxTail];
    uartRxTail = (uartRxTail + 1) % UART1_RX_BUFFER_SIZE;
    return dato;
}

/* =============================
 *  Enviar cadena
 * ============================= */
void UART1_Write_Text(const char *text)
{
    while (*text) {
        UART1_Write(*text++);
    }
}
