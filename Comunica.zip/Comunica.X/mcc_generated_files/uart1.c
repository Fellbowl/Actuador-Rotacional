#include "uart1.h"
#include <stdio.h>

/* Buffer sizes */
#define UART1_TX_BUFFER_SIZE 8
#define UART1_RX_BUFFER_SIZE 8

/* Global Variables */
volatile uint8_t uart1RxHead = 0;
volatile uint8_t uart1RxTail = 0;
volatile uint8_t uart1RxBuffer[UART1_RX_BUFFER_SIZE];
volatile uart1_status_t uart1RxStatusBuffer[UART1_RX_BUFFER_SIZE];
volatile uint8_t uart1RxCount = 0;
volatile uart1_status_t uart1RxLastError;

/* Prototypes */
void UART1_Receive_ISR(void);
void UART1_RxDataHandler(void);
void UART1_DefaultFramingErrorHandler(void);
void UART1_DefaultOverrunErrorHandler(void);
void UART1_DefaultErrorHandler(void);

/* Function pointers */
void (*UART1_RxDefaultInterruptHandler)(void);
void (*UART1_FramingErrorHandler)(void);
void (*UART1_OverrunErrorHandler)(void);
void (*UART1_ErrorHandler)(void);

/* Initialization */
void UART1_Initialize(void)
{
    // disable interrupts before changing states
    PIE3bits.RC1IE = 0;
    UART1_SetRxInterruptHandler(UART1_Receive_ISR);

    // BAUD1CON: ABDOVF no_overflow; SCKP Non-Inverted; BRG16 16-bit; WUE disabled; ABDEN disabled;
    BAUD1CON = 0x08;

    // RC1STA: SPEN enabled; RX9 8-bit; CREN enabled; ADDEN disabled; SREN disabled;
    RC1STA = 0x90;

    // TX1STA: TX9 8-bit; TXEN enabled; SYNC asynchronous; BRGH high speed;
    TX1STA = 0x24;

    // Baud rate = Fosc / (4 * (SP1BRGH:SP1BRGL + 1))
    SP1BRGL = 0xA0;
    SP1BRGH = 0x01;

    UART1_SetFramingErrorHandler(UART1_DefaultFramingErrorHandler);
    UART1_SetOverrunErrorHandler(UART1_DefaultOverrunErrorHandler);
    UART1_SetErrorHandler(UART1_DefaultErrorHandler);

    uart1RxLastError.status = 0;
    uart1RxHead = 0;
    uart1RxTail = 0;
    uart1RxCount = 0;

    // enable receive interrupt
    PIE3bits.RC1IE = 1;
}

bool UART1_is_tx_ready(void)
{
    return (bool)(PIR3bits.TX1IF && TX1STAbits.TXEN);
}

bool UART1_is_rx_ready(void)
{
    return (uart1RxCount ? true : false);
}

bool UART1_is_tx_done(void)
{
    return TX1STAbits.TRMT;
}

uart1_status_t UART1_get_last_status(void)
{
    return uart1RxLastError;
}

uint8_t UART1_Read(void)
{
    uint8_t readValue = 0;
    while (uart1RxCount == 0);

    uart1RxLastError = uart1RxStatusBuffer[uart1RxTail];
    readValue = uart1RxBuffer[uart1RxTail++];

    if (uart1RxTail >= sizeof(uart1RxBuffer))
        uart1RxTail = 0;

    PIE3bits.RC1IE = 0;
    uart1RxCount--;
    PIE3bits.RC1IE = 1;

    return readValue;
}

void UART1_Write(uint8_t txData)
{
    while (PIR3bits.TX1IF == 0);
    TX1REG = txData;
}

/* Interrupt Service Routine */
void UART1_Receive_ISR(void)
{
    uart1RxStatusBuffer[uart1RxHead].status = 0;

    if (RC1STAbits.FERR) {
        uart1RxStatusBuffer[uart1RxHead].ferr = 1;
        UART1_FramingErrorHandler();
    }

    if (RC1STAbits.OERR) {
        uart1RxStatusBuffer[uart1RxHead].oerr = 1;
        UART1_OverrunErrorHandler();
    }

    if (uart1RxStatusBuffer[uart1RxHead].status)
        UART1_ErrorHandler();
    else
        UART1_RxDataHandler();
}

void UART1_RxDataHandler(void)
{
    uart1RxBuffer[uart1RxHead++] = RC1REG;
    if (uart1RxHead >= sizeof(uart1RxBuffer))
        uart1RxHead = 0;
    uart1RxCount++;
}

/* Default Error Handlers */
void UART1_DefaultFramingErrorHandler(void) {}

void UART1_DefaultOverrunErrorHandler(void)
{
    RC1STAbits.CREN = 0;
    RC1STAbits.CREN = 1;
}

void UART1_DefaultErrorHandler(void)
{
    UART1_RxDataHandler();
}

/* Setters for custom handlers */
void UART1_SetFramingErrorHandler(void (*interruptHandler)(void))
{
    UART1_FramingErrorHandler = interruptHandler;
}

void UART1_SetOverrunErrorHandler(void (*interruptHandler)(void))
{
    UART1_OverrunErrorHandler = interruptHandler;
}

void UART1_SetErrorHandler(void (*interruptHandler)(void))
{
    UART1_ErrorHandler = interruptHandler;
}

void UART1_SetRxInterruptHandler(void (*interruptHandler)(void))
{
    UART1_RxDefaultInterruptHandler = interruptHandler;
}

/* Enviar n�mero por UART */
void enviarNumero(int numero)
{
    char buf[10];
    sprintf(buf, "%d\n", numero);

    static uint8_t txIndex = 0;
    if (buf[txIndex] != '\0') {
        UART1_Write(buf[txIndex]);
        txIndex++;
    } else {
        txIndex = 0;
    }
}

/* End of File */
