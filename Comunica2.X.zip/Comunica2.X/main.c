#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/timer/tmr0.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/system/pins.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

// =================== DEFINICIONES MANUALES DE LEDS ===================
#define LED_G00_LAT LATDbits.LATD0
#define LED_M03_LAT LATDbits.LATD1
#define LED_M05_LAT LATDbits.LATD2
#define LED_G28_LAT LATDbits.LATD3

#define LED_G00_SetHigh()  (LED_G00_LAT = 1)
#define LED_G00_SetLow()   (LED_G00_LAT = 0)
#define LED_M03_SetHigh()  (LED_M03_LAT = 1)
#define LED_M03_SetLow()   (LED_M03_LAT = 0)
#define LED_M05_SetHigh()  (LED_M05_LAT = 1)
#define LED_M05_SetLow()   (LED_M05_LAT = 0)
#define LED_G28_SetHigh()  (LED_G28_LAT = 1)
#define LED_G28_SetLow()   (LED_G28_LAT = 0)



// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G00,
    CMD_M03,
    CMD_M05,
    CMD_G28
} CommandID;

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    uint16_t posX;
    uint16_t velY;
    bool valid;
} G00_Command;

typedef struct {
    SystemState state;
    UART_Message msg;
    G00_Command g00;
    CommandID cmdID;
    bool txReady;
} SystemContext;

// =================== VARIABLES GLOBALES ===================
#define UART_RX_BUFFER_SIZE 16
#define UART_MSG_LEN 64

volatile char uartRxBuffer[UART_RX_BUFFER_SIZE][UART_MSG_LEN];
volatile uint8_t uartRxHead = 0;
volatile uint8_t uartRxTail = 0;
volatile uint8_t uartCharPos = 0;
volatile bool rxDataReady = false;
volatile uint16_t number = 0;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .g00 = {0, 0, false},
    .cmdID = CMD_NONE,
    .txReady = false
};

// =================== PROTOTIPOS ===================
static G00_Command parseG00(const char *input);
static int decodeGcode(const char *input);
void UART1_CustomHandler(void);
void RxFSM(void);
void TMR0_UserInterrupt(void);


void main(void)
{
    // Inicializaci�n del sistema
    SYSTEM_Initialize();
    
    // Registrar callback de UART1
    UART1_SetRxInterruptHandler(UART1_CustomHandler);

    // Registrar callback de TMR0 (ejemplo: enviar algo cada interrupci�n)
    TMR0_PeriodMatchCallbackRegister(TMR0_UserInterrupt);

    // Habilitar interrupciones globales
    INTCON0bits.GIEH = 1;  // Habilita interrupciones globales
    INTCON0bits.GIEL = 1;  // Habilita interrupciones perif�ricas

    // Apagar todos los LEDs antes de procesar el nuevo comando
    LED_G00_SetLow();
    LED_M03_SetLow();
    LED_M05_SetLow();
    LED_G28_SetLow();

    // Loop principal
    while (1)
    {
        RxFSM();
    }
}

// =================== CALLBACK DE UART ===================
void UART1_CustomHandler(void)
{
    uint8_t dato = UART1_Read(); // Lectura segura (ya maneja flags internos)

    uint8_t nextHead = (uartRxHead + 1) % UART_RX_BUFFER_SIZE;

    if (nextHead != uartRxTail) { // Hay espacio disponible
        uartRxBuffer[uartRxHead][uartCharPos++] = dato;

        // Fin de mensaje
        if (dato == '\n' || uartCharPos >= UART_MSG_LEN - 1) {
            uartRxBuffer[uartRxHead][uartCharPos] = '\0';
            uartCharPos = 0;
            uartRxHead = nextHead;
            rxDataReady = true;
        }
    }
}

// =================== CALLBACK DEL TIMER0 ===================
void TMR0_UserInterrupt(void)
{
    number++;
    UART1_SendNumber(number);
}

// =================== DECODIFICADOR DE COMANDOS ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "G00", 3) == 0) return CMD_G00;
    if (strncmp(input, "M03", 3) == 0) return CMD_M03;
    if (strncmp(input, "M05", 3) == 0) return CMD_M05;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}

static G00_Command parseG00(const char *input) {
    G00_Command cmd = {0, 0, false};
    const char *xPtr = strchr(input, 'X');
    const char *yPtr = strchr(input, 'Y');

    if (xPtr && yPtr) {
        int x = atoi(xPtr + 1);
        int y = atoi(yPtr + 1);
        if (x >= 0 && x <= 2000 && y >= 0 && y <= 24000) {
            cmd.posX = (uint16_t)x;
            cmd.velY = (uint16_t)y;
            cmd.valid = true;
        }
    }
    return cmd;
}

// =================== MAQUINA DE ESTADOS DE RECEPCI�N ===================
void RxFSM(void)
{
    if (uartRxTail == uartRxHead) return; // No hay mensajes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    systemCtx.cmdID = (CommandID)decodeGcode(msg);

    switch (systemCtx.cmdID) {
        case CMD_G00:
            systemCtx.g00 = parseG00(msg);
            if (systemCtx.g00.valid) {
 
                LED_G00_SetHigh();   // ? Activa LED para G00
                // StartTask(GoTo, systemCtx.g00.posX, systemCtx.g00.velY);
            } else {

            }
            break;

        case CMD_M03:

            LED_M03_SetHigh();  // ? Activa LED para M03
            break;

        case CMD_M05:

            LED_M05_SetHigh();  // ? Activa LED para M05
            break;

        case CMD_G28:

            LED_G28_SetHigh();  // ? Activa LED para G28
            // StartTask(GoHome, 0, 8000);
            break;

        default:

            break;
    }

    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}
