#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/timer/tmr0.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/system/pins.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>   

#define MAX_TASKS 10

volatile int32_t PulsosEncoder = 0; 
volatile int16_t SetPoint = 0; 
volatile int16_t PosActual = 0;
volatile int16_t Error = 0; 
volatile int16_t SalidaPID = 0; 
volatile bool Ts = false;

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G28,
    CMD_S,
    CMD_A,
    CMD_P,
    CMD_Ki,
    CMD_Kp,
    CMD_Kd        
} CommandID;

typedef enum {
    PID_ETAPA_0_LECTURA,
    PID_ETAPA_1_ERROR,
    PID_ETAPA_2_P,
    PID_ETAPA_3_I,
    PID_ETAPA_4_D,
    PID_ETAPA_5_SALIDA,
    PID_ETAPA_6_DUTY
} PID_Etapa_t;

typedef enum {
    NONE,
    Rx1,
    Rx2,
    Rx3,
    Rx4
} Envio_Datos;

typedef void (*TaskFunction)(int16_t, bool);

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    int16_t value;
    bool valid;
} SetPoint_Command;

typedef struct {
    float Ki, Kp, Kd;
} K_PID;

K_PID Constantes;

Envio_Datos transmision = NONE;

typedef enum {
    PID_FSM_IDLE = 0,
    PID_FSM_READING
} PID_FSM_State;

typedef enum {
    PID_TARGET_NONE = 0,
    PID_TARGET_KP,
    PID_TARGET_KI,
    PID_TARGET_KD
} PID_Target;

typedef struct {
    PID_Etapa_t etapa;
    int16_t PosActual;
    int16_t Error;
    int16_t ErrorPrev;
    int32_t SumError;
    int16_t Derivada;
    float P;
    float I;
    float D;
    float Acumulado;  // parcial para ir sumando P + I + D
    bool habilitado;
} PID_Data_t;

volatile PID_Data_t PID = {
    .etapa = PID_ETAPA_0_LECTURA,
    .habilitado = false
};

typedef struct {
    PID_FSM_State state;     // Si est� activa o no
    PID_Target target;       // Qu� constante se est� ajustando
    float value;             // Acumulado
    float divisor;           // Para decimales
    bool decimalMode;        // Si ya se vio ','
    uint8_t index;           // �ndice actual (3 ? 7)
    const char *buffer;      // Apuntador al mensaje recibido
} K_PID_FSM;

K_PID_FSM KParser;

typedef struct {
    SystemState state;
    UART_Message msg;
    SetPoint_Command pos;
    CommandID cmdID;
    bool txReady;
    bool digital;
} SystemContext;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .cmdID = CMD_NONE,
    .txReady = false,
    .digital = true
};

typedef struct {
    TaskFunction func;     
    int16_t pos;          
    bool started;          
    bool digital;
    uint8_t iterations;
} Task;

typedef struct {
    Task queue[MAX_TASKS];
    uint8_t head;
    uint8_t tail;
    bool running;
} TaskScheduler;

TaskScheduler scheduler = { .head = 0, .tail = 0, .running = false };

// =================== PROTOTIPOS ===================
static SetPoint_Command parseP(const char *input);
void K_PID_FSM_Process(void);
static int decodeGcode(const char *input);
void RxFSM(void);
void PID_MDF(bool);
void PID_Reset(void);
void Rx_datos(void);
void GoHome(int16_t, bool);
void GoTo(int16_t, bool);
void StartTask(TaskFunction, int16_t, bool);
void RunTasks(void);

void main(void)
{
    // Inicializaci�n del sistema
    SYSTEM_Initialize();
    
    // Registrar callback de UART1
    UART1_SetRxInterruptHandler(UART1_CustomHandler);

    // Registrar callback de TMR0 (ejemplo: enviar algo cada interrupci�n)
    TMR0_PeriodMatchCallbackRegister(TMR0_UserInterrupt);

    // Habilitar interrupciones globales
    INTCON0bits.GIEH = 1;  // Habilita interrupciones globales
    INTCON0bits.GIEL = 1;  // Habilita interrupciones perif�ricas
    
    Constantes.Ki = 1.1;
    Constantes.Kp = 1.2;
    Constantes.Kd = 1.3;
    
    // Loop principal
    while (1)
    {
        RxFSM();
        K_PID_FSM_Process();
        
        if (Ts) {                   // ? solo se ejecuta una vez por periodo
            Ts = false;             // ? limpia la bandera
            transmision = Rx1;      // ? ejecuta el control PID o tareas dependientes del muestreo
            RunTasks();             // ? avanza una iteraci�n de la tarea actual
        }
        
        Rx_datos();
    }
}


// =================== DECODIFICADOR DE COMANDOS ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "S", 1) == 0) return CMD_S;
    if (strncmp(input, "A", 1) == 0) return CMD_A;
    if (strncmp(input, "P", 1) == 0) return CMD_P;
    if (strncmp(input, "Ki", 1) == 0) return CMD_Ki;
    if (strncmp(input, "Kp", 1) == 0) return CMD_Kp;
    if (strncmp(input, "Kd", 1) == 0) return CMD_Kd;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}


static SetPoint_Command parseP(const char *input) {
    SetPoint_Command cmd = {0, false};

    // Apunta al n�mero despu�s de la 'P'
    const char *numPtr = input + 1;

    // Verifica formato: debe haber signo opcional seguido de d�gitos
    if (*numPtr == '+' || *numPtr == '-' || isdigit((unsigned char)*numPtr)) {
        int val = atoi(numPtr);
        if (val >= -14500 && val <= 14500) {
            cmd.value = (int16_t)val;
            cmd.valid = true;
        }
    }

    return cmd;
}

void K_PID_FSM_Process(void) {
    if (KParser.state == PID_FSM_IDLE) return;

    char c = KParser.buffer[KParser.index];

    if (c == ',') {
        KParser.decimalMode = true;
    }
    else if (c >= '0' && c <= '9') {
        if (!KParser.decimalMode) {
            KParser.value = KParser.value * 10.0f + (c - '0');
        } else {
            KParser.value += (float)(c - '0') / KParser.divisor;
            KParser.divisor *= 10.0f;
        }
    }

    KParser.index++;

    if (KParser.index > 7) {
        // FIN ? asignar seg�n target
        switch(KParser.target) {
            case PID_TARGET_KP: 
                Constantes.Kp = KParser.value;
                break;
            case PID_TARGET_KI: 
                Constantes.Ki = KParser.value;
                break;
            case PID_TARGET_KD: 
                Constantes.Kd = KParser.value;
                break;
            default: 
                break;
        }

        // Volver a reposo
        KParser.state = PID_FSM_IDLE;
        KParser.target = PID_TARGET_NONE;
    }
}


// =================== MAQUINA DE ESTADOS DE RECEPCI�N ===================
void RxFSM(void)
{
    if (uartRxTail == uartRxHead) return; // No hay mensajes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    systemCtx.cmdID = (CommandID)decodeGcode(msg);
        
    switch (systemCtx.cmdID) {
        case CMD_P:
            systemCtx.pos = parseP(msg);
            if (systemCtx.pos.valid && systemCtx.digital) {
                StartTask(GoTo, systemCtx.pos.value, true);
            } else {
            
            }
            break;
            
        case CMD_G28:
            StartTask(GoHome, 0, false);
            break;

        case CMD_S:
            systemCtx.digital = true;
            break;

        case CMD_A:
            systemCtx.digital = false;
            StartTask(GoTo, 0, false);
            break;
            
        case CMD_Kp:
            //agregar el if de que actuliza las constantes si esta ejecutando una tarea
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KP;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Ki:
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KI;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Kd:
            if (KParser.state == PID_FSM_IDLE && !scheduler.running) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KD;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

            
        default:

            break;
    }

    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}

void Rx_datos(void){
    switch(transmision)
    {
        case Rx1:
            UART1_SendNumber(SetPoint);
            transmision = Rx2;
            break;
            
        case Rx2:
            UART1_SendNumber(PosActual);
            transmision = Rx3;
            break;
            
        case Rx3:
            UART1_SendNumber(Error);
            transmision = Rx4;
            break;
            
        case Rx4:
            UART1_SendNumber(SalidaPID);
            transmision = NONE;
            break;
            
        case NONE:
            break;
    }
}

void PID_MDF(bool digital)
{
    if(!PID.habilitado)
        return;

    switch(PID.etapa)
    {
        case PID_ETAPA_0_LECTURA:
            if(digital){
                PID.PosActual = (int16_t)( ( PulsosEncoder * 35 ) / 10 );
                PID.etapa = PID_ETAPA_1_ERROR;
            }
            break;

        case PID_ETAPA_1_ERROR:
            PID.Error = SetPoint - PID.PosActual;
            PID.etapa = PID_ETAPA_2_P;
            break;

        case PID_ETAPA_2_P:
            PID.P = Constantes.Kp * PID.Error;
            PID.Acumulado = PID.P;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA; 
                break;
            }
            PID.etapa = PID_ETAPA_3_I;
            break;

        case PID_ETAPA_3_I:
            PID.SumError += PID.Error;
            PID.I = Constantes.Ki * (float)PID.SumError;
            PID.Acumulado += PID.I;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA; 
                break;
            }
            PID.etapa = PID_ETAPA_4_D;
            break;

        case PID_ETAPA_4_D:
            PID.Derivada = PID.Error - PID.ErrorPrev;
            PID.ErrorPrev = PID.Error;
            PID.D = Constantes.Kd * (float)PID.Derivada;
            PID.Acumulado += PID.D;
            PID.etapa = PID_ETAPA_5_SALIDA;
            break;

        case PID_ETAPA_5_SALIDA:
            // Saturaci�n final
            if(PID.Acumulado >  24.0f) PID.Acumulado =  24.0f;
            if(PID.Acumulado < -24.0f) PID.Acumulado = -24.0f;

            PID.Acumulado = PID.Acumulado / 6;

            // Terminar el ciclo
            PID.etapa = PID_ETAPA_6_DUTY;
            break;
        
        case PID_ETAPA_6_DUTY:
            // Saturaci�n final
            if(PID.Acumulado >  24.0f) PID.Acumulado =  24.0f;
            if(PID.Acumulado < -24.0f) PID.Acumulado = -24.0f;
            
            PosActual = PID.PosActual;
            Error = PID.Error;
            SalidaPID = (int16_t)(PID.Acumulado * 25);
            
            PID.habilitado = false;
            break;    
    }
}


void PID_Reset(void) {
    PID.etapa = PID_ETAPA_0_LECTURA;
    PID.PosActual = 0;
    PID.Error = 0;
    PID.ErrorPrev = 0;
    PID.SumError = 0;
    PID.Derivada = 0;
    PID.P = 0;
    PID.I = 0;
    PID.D = 0;
    PID.Acumulado = 0;
}


void GoHome(int16_t dummy, bool digital) {
    (void)dummy;  // sin uso
    // por ejemplo, resetear posici�n
    SetPoint = 0;
    PID_MDF(digital);
}


void GoTo(int16_t pos, bool digital) {
    static bool initialized = false;

    if (!initialized) {
        initialized = true;
        SetPoint = pos;
        PID.habilitado = true;
        PID_Reset();
    }

    PID_MDF(digital); // ejecuta una iteraci�n del control
}


void StartTask(void (*func)(int16_t, bool), int16_t pos, bool digital) {
    uint8_t next = (scheduler.tail + 1) % MAX_TASKS;
    if (next != scheduler.head) {
        scheduler.queue[scheduler.tail].func = func;
        scheduler.queue[scheduler.tail].pos = pos;
        scheduler.queue[scheduler.tail].digital = digital;
        scheduler.queue[scheduler.tail].started = false;
        scheduler.tail = next;
    }
}


void RunTasks(void) {
    if (scheduler.head == scheduler.tail) {
        scheduler.running = false;
        return;
    }

    scheduler.running = true;
    Task *current = &scheduler.queue[scheduler.head];

    if (!current->started) {
        current->started = true;
        current->iterations = 0;
    }

    // Ejecutar la tarea
    current->func(current->pos, current->digital);

    // Contar cu�ntas veces se ejecut�
    current->iterations++;

    // Si ya se ejecut� 60 veces, termina la tarea
    if (current->iterations >= 60) {
        scheduler.head = (scheduler.head + 1) % MAX_TASKS;
    }
}
